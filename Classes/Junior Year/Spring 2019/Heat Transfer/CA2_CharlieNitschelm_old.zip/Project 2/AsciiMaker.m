%Charlie Nitschelm
function [file] = AsciiMaker(Filepath,T1)

dlmwrite(Filepath,T1)
end

